package com.example.rentfinder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    // =====================================================
    // DATABASE
    // =====================================================

    private static final String DATABASE_NAME =
            "rentfinder.db";

    private static final int DATABASE_VERSION =
            4;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public DBHelper(Context context) {

        super(
                context,
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }


    // =====================================================
    // CREATE DATABASE
    // =====================================================

    @Override
    public void onCreate(SQLiteDatabase db) {

        // =================================================
        // USERS TABLE
        // =================================================

        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "name TEXT," +
                        "email TEXT UNIQUE," +
                        "password TEXT," +
                        "role TEXT)"
        );


        // =================================================
        // PROPERTIES TABLE
        // =================================================

        db.execSQL(
                "CREATE TABLE properties (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "owner_email TEXT," +
                        "property_name TEXT," +
                        "location TEXT," +
                        "rent TEXT," +
                        "room_type TEXT," +
                        "food TEXT," +
                        "wifi TEXT," +
                        "ac TEXT," +
                        "description TEXT," +
                        "status TEXT)"
        );
    }


    // =====================================================
    // DATABASE UPGRADE
    // =====================================================

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        /*
         * For development:
         * Recreate both tables without mobile.
         *
         * WARNING:
         * This deletes existing local database data
         * when upgrading from version 3 to 4.
         */

        db.execSQL(
                "DROP TABLE IF EXISTS properties"
        );

        db.execSQL(
                "DROP TABLE IF EXISTS users"
        );

        onCreate(db);
    }


    // =====================================================
    // REGISTER USER
    // =====================================================

    public boolean registerUser(
            String name,
            String email,
            String password,
            String role) {

        SQLiteDatabase db =
                this.getWritableDatabase();


        ContentValues values =
                new ContentValues();


        values.put(
                "name",
                name
        );


        values.put(
                "email",
                email
        );


        values.put(
                "password",
                password
        );


        values.put(
                "role",
                role
        );


        long result =
                db.insert(
                        "users",
                        null,
                        values
                );


        return result != -1;
    }


    // =====================================================
    // CHECK EMAIL ALREADY REGISTERED
    // =====================================================

    public boolean isEmailRegistered(
            String email) {

        SQLiteDatabase db =
                this.getReadableDatabase();


        Cursor cursor =
                db.rawQuery(
                        "SELECT id FROM users WHERE email=?",
                        new String[]{
                                email
                        }
                );


        boolean exists =
                cursor.getCount() > 0;


        cursor.close();


        return exists;
    }


    // =====================================================
    // LOGIN
    // =====================================================

    public boolean checkLogin(
            String email,
            String password,
            String role) {

        SQLiteDatabase db =
                this.getReadableDatabase();


        Cursor cursor =
                db.rawQuery(
                        "SELECT * FROM users " +
                                "WHERE email=? " +
                                "AND password=? " +
                                "AND role=?",

                        new String[]{
                                email,
                                password,
                                role
                        }
                );


        boolean result =
                cursor.getCount() > 0;


        cursor.close();


        return result;
    }


    // =====================================================
    // GET USER NAME
    // =====================================================

    public String getUserName(
            String email) {

        SQLiteDatabase db =
                this.getReadableDatabase();


        Cursor cursor =
                db.rawQuery(
                        "SELECT name FROM users WHERE email=?",

                        new String[]{
                                email
                        }
                );


        String name = "";


        if (cursor.moveToFirst()) {

            name =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "name"
                            )
                    );
        }


        cursor.close();


        return name;
    }


    // =====================================================
    // ADD PROPERTY
    // =====================================================

    public boolean addProperty(
            String ownerEmail,
            String propertyName,
            String location,
            String rent,
            String roomType,
            String food,
            String wifi,
            String ac,
            String description) {

        SQLiteDatabase db =
                this.getWritableDatabase();


        ContentValues values =
                new ContentValues();


        values.put(
                "owner_email",
                ownerEmail
        );


        values.put(
                "property_name",
                propertyName
        );


        values.put(
                "location",
                location
        );


        values.put(
                "rent",
                rent
        );


        values.put(
                "room_type",
                roomType
        );


        values.put(
                "food",
                food
        );


        values.put(
                "wifi",
                wifi
        );


        values.put(
                "ac",
                ac
        );


        values.put(
                "description",
                description
        );


        // =============================================
        // PROPERTY REQUIRES ADMIN APPROVAL
        // =============================================

        values.put(
                "status",
                "Pending"
        );


        long result =
                db.insert(
                        "properties",
                        null,
                        values
                );


        return result != -1;
    }


    // =====================================================
    // GET OWNER PROPERTIES
    // =====================================================

    public Cursor getOwnerProperties(
            String ownerEmail) {

        SQLiteDatabase db =
                this.getReadableDatabase();


        return db.rawQuery(
                "SELECT * FROM properties " +
                        "WHERE owner_email=? " +
                        "ORDER BY id DESC",

                new String[]{
                        ownerEmail
                }
        );
    }


    // =====================================================
    // GET ALL APPROVED PROPERTIES
    // =====================================================

    public Cursor getApprovedProperties() {

        SQLiteDatabase db =
                this.getReadableDatabase();


        return db.rawQuery(
                "SELECT * FROM properties " +
                        "WHERE status='Approved' " +
                        "ORDER BY id DESC",

                null
        );
    }


    // =====================================================
    // GET PENDING PROPERTIES
    // =====================================================

    public Cursor getPendingProperties() {

        SQLiteDatabase db =
                this.getReadableDatabase();


        return db.rawQuery(
                "SELECT * FROM properties " +
                        "WHERE status='Pending' " +
                        "ORDER BY id DESC",

                null
        );
    }


    // =====================================================
    // UPDATE PROPERTY STATUS
    // =====================================================

    public boolean updatePropertyStatus(
            int propertyId,
            String status) {

        SQLiteDatabase db =
                this.getWritableDatabase();


        ContentValues values =
                new ContentValues();


        values.put(
                "status",
                status
        );


        int result =
                db.update(
                        "properties",
                        values,

                        "id=?",

                        new String[]{
                                String.valueOf(propertyId)
                        }
                );


        return result > 0;
    }


    // =====================================================
    // DELETE PROPERTY
    // =====================================================

    public boolean deleteProperty(
            int propertyId) {

        SQLiteDatabase db =
                this.getWritableDatabase();


        int result =
                db.delete(
                        "properties",

                        "id=?",

                        new String[]{
                                String.valueOf(propertyId)
                        }
                );


        return result > 0;
    }
}
