package com.example.rentfinder;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class StudentHomeActivity extends AppCompatActivity {

    TextView tvHello;
    TextView tvAvailable;

    Button btnFindRooms;
    Button btnSaved;
    Button btnEnquiries;
    Button btnVisits;
    Button btnProfile;
    Button btnLogout;

    String studentEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_student_home);

        // =================================
        // FIND VIEWS
        // =================================

        tvHello = findViewById(R.id.tvHello);
        tvAvailable = findViewById(R.id.tvAvailable);

        btnFindRooms = findViewById(R.id.btnFindRooms);
        btnSaved = findViewById(R.id.btnSaved);
        btnEnquiries = findViewById(R.id.btnEnquiries);
        btnVisits = findViewById(R.id.btnVisits);
        btnProfile = findViewById(R.id.btnProfile);
        btnLogout = findViewById(R.id.btnLogout);


        // =================================
        // GET STUDENT EMAIL
        // =================================

        studentEmail = getIntent().getStringExtra("email");

        if (studentEmail != null && !studentEmail.isEmpty()) {

            tvHello.setText(
                    "Hello, Student 👋\n" +
                            studentEmail
            );

        } else {

            tvHello.setText("Hello, Student 👋");
        }


        // =================================
        // DASHBOARD SUBTITLE
        // =================================

        tvAvailable.setText(
                "Find affordable rooms, PGs and hostels"
        );


        // =================================
        // FIND ROOMS
        // =================================

        btnFindRooms.setOnClickListener(v -> {

            Intent intent = new Intent(
                    StudentHomeActivity.this,
                    FindRoomsActivity.class
            );

            intent.putExtra(
                    "student_email",
                    studentEmail
            );

            startActivity(intent);
        });


        // =================================
        // SAVED PROPERTIES
        // =================================

        btnSaved.setOnClickListener(v -> {

            Toast.makeText(
                    StudentHomeActivity.this,
                    "Saved Properties coming soon ❤️",
                    Toast.LENGTH_SHORT
            ).show();

        });


        // =================================
        // MY ENQUIRIES
        // =================================

        btnEnquiries.setOnClickListener(v -> {

            Toast.makeText(
                    StudentHomeActivity.this,
                    "My Enquiries coming soon 💬",
                    Toast.LENGTH_SHORT
            ).show();

        });


        // =================================
        // VISIT REQUESTS
        // =================================

        btnVisits.setOnClickListener(v -> {

            Toast.makeText(
                    StudentHomeActivity.this,
                    "Visit Requests coming soon 📅",
                    Toast.LENGTH_SHORT
            ).show();

        });


        // =================================
        // PROFILE
        // =================================

        btnProfile.setOnClickListener(v -> {

            Toast.makeText(
                    StudentHomeActivity.this,
                    "Student Profile coming soon 👤",
                    Toast.LENGTH_SHORT
            ).show();

        });


        // =================================
        // LOGOUT
        // =================================

        btnLogout.setOnClickListener(v -> {

            Intent intent = new Intent(
                    StudentHomeActivity.this,
                    LoginActivity.class
            );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);

            Toast.makeText(
                    StudentHomeActivity.this,
                    "Logged out successfully",
                    Toast.LENGTH_SHORT
            ).show();
        });
    }
}