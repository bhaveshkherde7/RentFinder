package com.example.rentfinder;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class OTPActivity extends AppCompatActivity {

    // =========================================
    // VIEWS
    // =========================================

    private EditText etOtp;
    private Button btnVerifyOtp;
    private Button btnResendOtp;
    private TextView tvOtpEmail;


    // =========================================
    // LOGIN DATA
    // =========================================

    private String email;
    private String password;
    private String role;

    // Generated OTP
    private String generatedOtp;


    // =========================================
    // OTP VALIDITY
    // =========================================

    private boolean otpExpired = false;

    private Handler otpHandler = new Handler(
            Looper.getMainLooper()
    );


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_otp);


        // =========================================
        // FIND VIEWS
        // =========================================

        etOtp = findViewById(R.id.etOtp);

        btnVerifyOtp = findViewById(R.id.btnVerifyOtp);

        btnResendOtp = findViewById(R.id.btnResendOtp);

        tvOtpEmail = findViewById(R.id.tvOtpEmail);


        // =========================================
        // GET LOGIN DATA
        // =========================================

        email = getIntent().getStringExtra("email");

        password = getIntent().getStringExtra("password");

        role = getIntent().getStringExtra("role");


        // =========================================
        // CHECK EMAIL
        // =========================================

        if (email == null || email.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    "Email not found",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }


        // =========================================
        // SHOW EMAIL
        // =========================================

        tvOtpEmail.setText(
                "OTP has been sent to\n" + email
        );


        // =========================================
        // SEND FIRST OTP
        // =========================================

        sendOTP();


        // =========================================
        // VERIFY OTP
        // =========================================

        btnVerifyOtp.setOnClickListener(v -> {

            String enteredOtp =
                    etOtp.getText()
                            .toString()
                            .trim();


            // Empty OTP

            if (enteredOtp.isEmpty()) {

                etOtp.setError(
                        "Please enter OTP"
                );

                etOtp.requestFocus();

                return;
            }


            // OTP length

            if (enteredOtp.length() != 6) {

                etOtp.setError(
                        "OTP must be 6 digits"
                );

                etOtp.requestFocus();

                return;
            }


            // Verify

            verifyOTP(enteredOtp);

        });


        // =========================================
        // RESEND OTP
        // =========================================

        btnResendOtp.setOnClickListener(v -> {

            etOtp.setText("");

            sendOTP();

        });
    }


    // =========================================
    // GENERATE + SEND OTP
    // =========================================

    private void sendOTP() {

        // Generate 6 digit OTP

        Random random = new Random();

        int otpNumber =
                100000 + random.nextInt(900000);

        generatedOtp =
                String.valueOf(otpNumber);


        // OTP is valid again

        otpExpired = false;


        // =========================================
        // REAL EMAIL SENDING
        // =========================================

        /*
         * IMPORTANT:
         *
         * This is where your email API/backend
         * should be called.
         *
         * Android should NOT contain your
         * Gmail password or SMTP password.
         *
         * Your backend should send:
         *
         * To: email
         *
         * Subject:
         * RentFinder Login OTP
         *
         * Message:
         * Your OTP is: 123456
         *
         */


        // =========================================
        // SHOW STATUS ONLY
        // =========================================

        showLongToast(
                "OTP sent to your email"
        );


        // =========================================
        // OTP EXPIRES AFTER 5 MINUTES
        // =========================================

        otpHandler.postDelayed(
                () -> {

                    otpExpired = true;

                    generatedOtp = null;

                },
                5 * 60 * 1000
        );
    }


    // =========================================
    // VERIFY OTP
    // =========================================

    private void verifyOTP(String enteredOtp) {


        // =========================================
        // CHECK EXPIRATION
        // =========================================

        if (otpExpired) {

            Toast.makeText(
                    this,
                    "OTP has expired. Please resend OTP.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }


        // =========================================
        // CHECK OTP
        // =========================================

        if (generatedOtp != null &&
                enteredOtp.equals(generatedOtp)) {

            Toast.makeText(
                    this,
                    "OTP Verified Successfully ✓",
                    Toast.LENGTH_SHORT
            ).show();


            // Prevent OTP reuse

            generatedOtp = null;


            // Login

            loginUser();

        } else {

            Toast.makeText(
                    this,
                    "Incorrect OTP ❌",
                    Toast.LENGTH_LONG
            ).show();

            etOtp.setText("");

            etOtp.requestFocus();
        }
    }


    // =========================================
    // LOGIN USER
    // =========================================

    private void loginUser() {

        Intent intent;


        // =========================================
        // STUDENT
        // =========================================

        if (role != null &&
                role.equalsIgnoreCase("Student")) {

            intent = new Intent(
                    OTPActivity.this,
                    StudentHomeActivity.class
            );
        }


        // =========================================
        // OWNER
        // =========================================

        else if (role != null &&
                role.equalsIgnoreCase("Owner")) {

            intent = new Intent(
                    OTPActivity.this,
                    OwnerHomeActivity.class
            );
        }


        // =========================================
        // ADMIN
        // =========================================

        else if (role != null &&
                role.equalsIgnoreCase("Admin")) {

            intent = new Intent(
                    OTPActivity.this,
                    AdminDashboardActivity.class
            );
        }


        // =========================================
        // INVALID ROLE
        // =========================================

        else {

            Toast.makeText(
                    this,
                    "Invalid role",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        // =========================================
        // SEND EMAIL
        // =========================================

        intent.putExtra(
                "email",
                email
        );


        // =========================================
        // SEND ROLE
        // =========================================

        intent.putExtra(
                "role",
                role
        );


        // =========================================
        // CLEAR LOGIN SCREEN
        // =========================================

        intent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_CLEAR_TASK
        );


        startActivity(intent);

        finish();
    }


    // =========================================
    // 4 SECOND TOAST
    // =========================================

    private void showLongToast(String message) {

        Toast toast = Toast.makeText(
                this,
                message,
                Toast.LENGTH_LONG
        );

        toast.show();


        // Keep Toast for approximately 4 seconds

        new Handler(
                Looper.getMainLooper()
        ).postDelayed(
                toast::cancel,
                4000
        );
    }


    // =========================================
    // CLEAN UP
    // =========================================

    @Override
    protected void onDestroy() {

        super.onDestroy();

        otpHandler.removeCallbacksAndMessages(null);
    }
}