package com.example.rentfinder;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PostRoomActivity extends AppCompatActivity {

    EditText etPropertyName;
    EditText etLocation;
    EditText etRent;
    EditText etDescription;

    Spinner spinnerRoomType;
    Spinner spinnerFood;
    Spinner spinnerWifi;
    Spinner spinnerAC;

    Button btnSaveProperty;

    DBHelper dbHelper;

    String ownerEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_post_room);

        // =========================
        // FIND VIEWS
        // =========================

        etPropertyName = findViewById(R.id.etPropertyName);
        etLocation = findViewById(R.id.etLocation);
        etRent = findViewById(R.id.etRent);
        etDescription = findViewById(R.id.etDescription);

        spinnerRoomType = findViewById(R.id.spinnerRoomType);
        spinnerFood = findViewById(R.id.spinnerFood);
        spinnerWifi = findViewById(R.id.spinnerWifi);
        spinnerAC = findViewById(R.id.spinnerAC);

        btnSaveProperty = findViewById(R.id.btnSaveProperty);

        dbHelper = new DBHelper(this);

        ownerEmail = getIntent().getStringExtra("owner_email");


        // =========================
        // ROOM TYPE
        // =========================

        String[] roomTypes = {
                "Single Room",
                "2 Sharing",
                "3 Sharing",
                "4 Sharing",
                "PG"
        };

        ArrayAdapter<String> roomAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        roomTypes
                );

        spinnerRoomType.setAdapter(roomAdapter);


        // =========================
        // FOOD
        // =========================

        String[] foodOptions = {
                "Available",
                "Not Available"
        };

        ArrayAdapter<String> foodAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        foodOptions
                );

        spinnerFood.setAdapter(foodAdapter);


        // =========================
        // WIFI
        // =========================

        String[] wifiOptions = {
                "Available",
                "Not Available"
        };

        ArrayAdapter<String> wifiAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        wifiOptions
                );

        spinnerWifi.setAdapter(wifiAdapter);


        // =========================
        // AC
        // =========================

        String[] acOptions = {
                "Available",
                "Not Available"
        };

        ArrayAdapter<String> acAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        acOptions
                );

        spinnerAC.setAdapter(acAdapter);


        // =========================
        // SAVE PROPERTY
        // =========================

        btnSaveProperty.setOnClickListener(v -> {

            String propertyName =
                    etPropertyName.getText().toString().trim();

            String location =
                    etLocation.getText().toString().trim();

            String rent =
                    etRent.getText().toString().trim();

            String description =
                    etDescription.getText().toString().trim();

            String roomType =
                    spinnerRoomType.getSelectedItem().toString();

            String food =
                    spinnerFood.getSelectedItem().toString();

            String wifi =
                    spinnerWifi.getSelectedItem().toString();

            String ac =
                    spinnerAC.getSelectedItem().toString();


            // =========================
            // VALIDATION
            // =========================

            if (propertyName.isEmpty()) {

                etPropertyName.setError("Enter property name");
                etPropertyName.requestFocus();
                return;
            }

            if (location.isEmpty()) {

                etLocation.setError("Enter location");
                etLocation.requestFocus();
                return;
            }

            if (rent.isEmpty()) {

                etRent.setError("Enter monthly rent");
                etRent.requestFocus();
                return;
            }

            if (description.isEmpty()) {

                etDescription.setError("Enter description");
                etDescription.requestFocus();
                return;
            }


            // =========================
            // INSERT PROPERTY
            // =========================

            SQLiteDatabase db =
                    dbHelper.getWritableDatabase();

            ContentValues values =
                    new ContentValues();

            values.put("owner_email", ownerEmail);
            values.put("property_name", propertyName);
            values.put("location", location);
            values.put("rent", rent);
            values.put("room_type", roomType);
            values.put("food", food);
            values.put("wifi", wifi);
            values.put("ac", ac);
            values.put("description", description);

            // New property waits for admin approval
            values.put("status", "Pending");

            long result =
                    db.insert(
                            "properties",
                            null,
                            values
                    );

            if (result != -1) {

                Toast.makeText(
                        PostRoomActivity.this,
                        "Property submitted for admin approval",
                        Toast.LENGTH_LONG
                ).show();

                finish();

            } else {

                Toast.makeText(
                        PostRoomActivity.this,
                        "Failed to save property",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}