package com.example.rentfinder;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class FindRoomsActivity extends AppCompatActivity {

    TextView tvTitle;
    ListView listRooms;

    DBHelper dbHelper;

    ArrayList<String> roomList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_find_rooms);

        tvTitle = findViewById(R.id.tvTitle);
        listRooms = findViewById(R.id.listRooms);

        dbHelper = new DBHelper(this);

        tvTitle.setText("Available Rooms 🏠");

        roomList = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                roomList
        );

        listRooms.setAdapter(adapter);

        loadRooms();


        // CLICK PROPERTY
        listRooms.setOnItemClickListener(
                (parent, view, position, id) -> {

                    Toast.makeText(
                            FindRoomsActivity.this,
                            "Property selected",
                            Toast.LENGTH_SHORT
                    ).show();

                }
        );
    }


    private void loadRooms() {

        roomList.clear();

        Cursor cursor =
                dbHelper.getApprovedProperties();

        if (cursor.getCount() == 0) {

            roomList.add(
                    "No approved properties available yet."
            );

        } else {

            while (cursor.moveToNext()) {

                // Column positions:
                // 0 = id
                // 1 = owner_email
                // 2 = property_name
                // 3 = location
                // 4 = rent
                // 5 = room_type
                // 6 = food
                // 7 = wifi
                // 8 = ac
                // 9 = description
                // 10 = status

                String name =
                        cursor.getString(2);

                String location =
                        cursor.getString(3);

                String rent =
                        cursor.getString(4);

                String roomType =
                        cursor.getString(5);

                String food =
                        cursor.getString(6);

                String wifi =
                        cursor.getString(7);

                String ac =
                        cursor.getString(8);

                String description =
                        cursor.getString(9);


                String room =
                        "🏠 " + name +
                                "\n📍 " + location +
                                "\n💰 ₹" + rent + "/month" +
                                "\n🛏 " + roomType +
                                "\n🍱 Food: " + food +
                                "\n📶 Wi-Fi: " + wifi +
                                "\n❄ AC: " + ac +
                                "\n📝 " + description;

                roomList.add(room);
            }
        }

        cursor.close();

        adapter.notifyDataSetChanged();
    }


    @Override
    protected void onResume() {
        super.onResume();

        if (dbHelper != null) {
            loadRooms();
        }
    }
}