package com.example.rentfinder;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    EditText etName;
    EditText etEmail;
    EditText etPassword;

    Spinner spinnerRole;

    Button btnRegister;
    Button btnGoLogin;

    DBHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register);


        // =================================
        // FIND VIEWS
        // =================================

        etName = findViewById(R.id.etName);

        etEmail = findViewById(R.id.etEmail);

        etPassword = findViewById(R.id.etPassword);

        spinnerRole = findViewById(R.id.spinnerRole);

        btnRegister = findViewById(R.id.btnRegister);

        // This exists in the attractive XML
        btnGoLogin = findViewById(R.id.btnGoLogin);


        // =================================
        // DATABASE
        // =================================

        dbHelper = new DBHelper(this);


        // =================================
        // ROLE
        // =================================

        String[] roles = {
                "Student",
                "Owner"
        };


        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        roles
                );


        spinnerRole.setAdapter(adapter);


        // =================================
        // REGISTER
        // =================================

        btnRegister.setOnClickListener(v -> {

            String name =
                    etName.getText()
                            .toString()
                            .trim();

            String email =
                    etEmail.getText()
                            .toString()
                            .trim();

            String password =
                    etPassword.getText()
                            .toString()
                            .trim();

            String role =
                    spinnerRole
                            .getSelectedItem()
                            .toString();


            // =================================
            // VALIDATION
            // =================================

            if (name.isEmpty()) {

                etName.setError(
                        "Enter your full name"
                );

                etName.requestFocus();

                return;
            }


            if (email.isEmpty()) {

                etEmail.setError(
                        "Enter your email"
                );

                etEmail.requestFocus();

                return;
            }


            // Check valid email

            if (!android.util.Patterns.EMAIL_ADDRESS
                    .matcher(email)
                    .matches()) {

                etEmail.setError(
                        "Enter a valid email"
                );

                etEmail.requestFocus();

                return;
            }


            if (password.isEmpty()) {

                etPassword.setError(
                        "Enter password"
                );

                etPassword.requestFocus();

                return;
            }


            if (password.length() < 6) {

                etPassword.setError(
                        "Password must be at least 6 characters"
                );

                etPassword.requestFocus();

                return;
            }


            // =================================
            // CHECK EMAIL
            // =================================

            if (dbHelper.isEmailRegistered(email)) {

                Toast.makeText(
                        RegisterActivity.this,
                        "Email already registered",
                        Toast.LENGTH_LONG
                ).show();

                return;
            }


            // =================================
            // OPEN OTP SCREEN
            // =================================

            Intent intent =
                    new Intent(
                            RegisterActivity.this,
                            RegisterOTPActivity.class
                    );


            // Send registration details

            intent.putExtra(
                    "name",
                    name
            );

            intent.putExtra(
                    "email",
                    email
            );

            intent.putExtra(
                    "password",
                    password
            );

            intent.putExtra(
                    "role",
                    role
            );


            startActivity(intent);
        });


        // =================================
        // GO TO LOGIN
        // =================================

        btnGoLogin.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            RegisterActivity.this,
                            LoginActivity.class
                    );

            startActivity(intent);

            finish();
        });
    }
}