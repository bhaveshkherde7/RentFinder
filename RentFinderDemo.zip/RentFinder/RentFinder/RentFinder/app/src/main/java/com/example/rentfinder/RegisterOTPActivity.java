package com.example.rentfinder;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class RegisterOTPActivity extends AppCompatActivity {

    // ==============================
    // VIEWS
    // ==============================

    EditText etRegisterOtp;

    Button btnVerifyRegisterOtp;
    Button btnResendRegisterOtp;

    TextView tvRegisterOtpEmail;


    // ==============================
    // REGISTRATION DATA
    // ==============================

    String name;
    String email;
    String password;
    String role;

    String generatedOtp;


    // ==============================
    // DATABASE
    // ==============================

    DBHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_register_otp
        );


        // =================================
        // FIND VIEWS
        // =================================

        etRegisterOtp =
                findViewById(
                        R.id.etRegisterOtp
                );

        btnVerifyRegisterOtp =
                findViewById(
                        R.id.btnVerifyRegisterOtp
                );

        btnResendRegisterOtp =
                findViewById(
                        R.id.btnResendRegisterOtp
                );

        tvRegisterOtpEmail =
                findViewById(
                        R.id.tvRegisterOtpEmail
                );


        // =================================
        // DATABASE
        // =================================

        dbHelper =
                new DBHelper(this);


        // =================================
        // GET DATA FROM REGISTER ACTIVITY
        // =================================

        name =
                getIntent().getStringExtra("name");

        email =
                getIntent().getStringExtra("email");

        password =
                getIntent().getStringExtra("password");

        role =
                getIntent().getStringExtra("role");


        // =================================
        // DISPLAY EMAIL
        // =================================

        if (email != null) {

            tvRegisterOtpEmail.setText(
                    "OTP verification for\n" + email
            );

        } else {

            tvRegisterOtpEmail.setText(
                    "Enter the OTP to continue"
            );
        }


        // =================================
        // GENERATE OTP
        // =================================

        generateOTP();


        // =================================
        // VERIFY OTP
        // =================================

        btnVerifyRegisterOtp.setOnClickListener(v -> {

            String enteredOtp =
                    etRegisterOtp
                            .getText()
                            .toString()
                            .trim();


            // =================================
            // EMPTY OTP
            // =================================

            if (enteredOtp.isEmpty()) {

                etRegisterOtp.setError(
                        "Enter OTP"
                );

                etRegisterOtp.requestFocus();

                return;
            }


            // =================================
            // OTP LENGTH
            // =================================

            if (enteredOtp.length() != 6) {

                etRegisterOtp.setError(
                        "OTP must be 6 digits"
                );

                etRegisterOtp.requestFocus();

                return;
            }


            // =================================
            // CHECK OTP
            // =================================

            if (enteredOtp.equals(generatedOtp)) {


                // =================================
                // SAVE USER TO DATABASE
                // =================================

                boolean result =
                        dbHelper.registerUser(
                                name,
                                email,
                                password,
                                role
                        );


                // =================================
                // REGISTRATION SUCCESS
                // =================================

                if (result) {

                    Toast.makeText(
                            RegisterOTPActivity.this,
                            "Account created successfully ✓",
                            Toast.LENGTH_LONG
                    ).show();


                    // =================================
                    // GO TO LOGIN
                    // =================================

                    Intent intent =
                            new Intent(
                                    RegisterOTPActivity.this,
                                    LoginActivity.class
                            );


                    intent.setFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK |
                                    Intent.FLAG_ACTIVITY_CLEAR_TASK
                    );


                    startActivity(intent);

                    finish();


                } else {

                    Toast.makeText(
                            RegisterOTPActivity.this,
                            "Registration failed ❌\nEmail may already exist.",
                            Toast.LENGTH_LONG
                    ).show();
                }


            } else {

                // =================================
                // WRONG OTP
                // =================================

                Toast.makeText(
                        RegisterOTPActivity.this,
                        "Incorrect OTP ❌",
                        Toast.LENGTH_LONG
                ).show();

                etRegisterOtp.setText("");
            }

        });


        // =================================
        // RESEND OTP
        // =================================

        btnResendRegisterOtp.setOnClickListener(v -> {

            generateOTP();

            etRegisterOtp.setText("");

            Toast.makeText(
                    RegisterOTPActivity.this,
                    "New OTP generated",
                    Toast.LENGTH_SHORT
            ).show();
        });

    }


    // =========================================
    // GENERATE 6 DIGIT OTP
    // =========================================

    private void generateOTP() {

        Random random =
                new Random();

        int otp =
                100000 +
                        random.nextInt(900000);

        generatedOtp =
                String.valueOf(otp);


        // =================================
        // DEMO OTP
        // =================================

        Toast.makeText(
                RegisterOTPActivity.this,
                "Your OTP is: " + generatedOtp,
                Toast.LENGTH_LONG
        ).show();
    }
}