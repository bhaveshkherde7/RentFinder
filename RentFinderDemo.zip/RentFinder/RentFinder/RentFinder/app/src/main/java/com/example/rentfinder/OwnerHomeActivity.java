package com.example.rentfinder;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class OwnerHomeActivity extends AppCompatActivity {

    TextView tvHello;
    TextView tvProperties;
    TextView tvEnquiries;
    TextView tvVisits;

    Button btnAddProperty;
    Button btnLogout;

    LinearLayout layoutProperties;
    LinearLayout layoutEnquiries;
    LinearLayout layoutVisits;
    LinearLayout layoutReviews;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_home);

        // =========================
        // FIND VIEWS
        // =========================

        tvHello = findViewById(R.id.tvHello);
        tvProperties = findViewById(R.id.tvProperties);
        tvEnquiries = findViewById(R.id.tvEnquiries);
        tvVisits = findViewById(R.id.tvVisits);

        btnAddProperty = findViewById(R.id.btnAddProperty);
        btnLogout = findViewById(R.id.btnLogout);

        layoutProperties = findViewById(R.id.layoutProperties);
        layoutEnquiries = findViewById(R.id.layoutEnquiries);
        layoutVisits = findViewById(R.id.layoutVisits);
        layoutReviews = findViewById(R.id.layoutReviews);


        // =========================
        // GET OWNER EMAIL
        // =========================

        String email = getIntent().getStringExtra("email");

        if (email != null && !email.isEmpty()) {
            tvHello.setText("Hello, Owner 👋\n" + email);
        } else {
            tvHello.setText("Hello, Owner 👋");
        }


        // =========================
        // DASHBOARD DATA
        // =========================

        // Temporary values
        // Later we will get these from SQLite

        tvProperties.setText("3");
        tvEnquiries.setText("12");
        tvVisits.setText("5");


        // =========================
        // ADD NEW PROPERTY
        // =========================

        btnAddProperty.setOnClickListener(v -> {

            Intent intent = new Intent(
                    OwnerHomeActivity.this,
                    PostRoomActivity.class
            );

            intent.putExtra("owner_email", email);

            startActivity(intent);
        });


        // =========================
        // MY PROPERTIES
        // =========================

        layoutProperties.setOnClickListener(v -> {

            Intent intent = new Intent(
                    OwnerHomeActivity.this,
                    MyPropertiesActivity.class
            );

            intent.putExtra("owner_email", email);

            startActivity(intent);
        });


        // =========================
        // STUDENT ENQUIRIES
        // =========================

        layoutEnquiries.setOnClickListener(v -> {

            Intent intent = new Intent(
                    OwnerHomeActivity.this,
                    OwnerRequestsActivity.class
            );

            intent.putExtra("owner_email", email);

            startActivity(intent);
        });


        // =========================
        // VISIT REQUESTS
        // =========================

        layoutVisits.setOnClickListener(v -> {

            Toast.makeText(
                    OwnerHomeActivity.this,
                    "Visit Requests",
                    Toast.LENGTH_SHORT
            ).show();

        });


        // =========================
        // REVIEWS
        // =========================

        layoutReviews.setOnClickListener(v -> {

            Toast.makeText(
                    OwnerHomeActivity.this,
                    "Reviews & Ratings",
                    Toast.LENGTH_SHORT
            ).show();

        });


        // =========================
        // LOGOUT
        // =========================

        btnLogout.setOnClickListener(v -> {

            Intent intent = new Intent(
                    OwnerHomeActivity.this,
                    LoginActivity.class
            );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);

            Toast.makeText(
                    OwnerHomeActivity.this,
                    "Logged out successfully",
                    Toast.LENGTH_SHORT
            ).show();
        });
    }
}