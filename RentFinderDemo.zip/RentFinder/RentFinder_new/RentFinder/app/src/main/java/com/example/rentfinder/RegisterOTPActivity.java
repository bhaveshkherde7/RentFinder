package com.example.rentfinder;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class RegisterOTPActivity extends AppCompatActivity {

    private EditText etRegisterOtp;

    private Button btnVerifyRegisterOtp;
    private Button btnResendRegisterOtp;

    private TextView tvRegisterOtpEmail;

    private String name;
    private String email;
    private String password;
    private String role;

    private String generatedOtp;

    private DBHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_register_otp
        );


        // =================================
        // FIND VIEWS
        // =================================

        etRegisterOtp =
                findViewById(
                        R.id.etRegisterOtp
                );

        btnVerifyRegisterOtp =
                findViewById(
                        R.id.btnVerifyRegisterOtp
                );

        btnResendRegisterOtp =
                findViewById(
                        R.id.btnResendRegisterOtp
                );

        tvRegisterOtpEmail =
                findViewById(
                        R.id.tvRegisterOtpEmail
                );


        // =================================
        // DATABASE
        // =================================

        dbHelper =
                new DBHelper(this);


        // =================================
        // GET REGISTER DATA
        // =================================

        name =
                getIntent().getStringExtra(
                        "name"
                );

        email =
                getIntent().getStringExtra(
                        "email"
                );

        password =
                getIntent().getStringExtra(
                        "password"
                );

        role =
                getIntent().getStringExtra(
                        "role"
                );


        // =================================
        // CHECK EMAIL
        // =================================

        if (email == null ||
                email.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    "Email is missing",
                    Toast.LENGTH_LONG
            ).show();

            finish();

            return;
        }


        // =================================
        // DISPLAY EMAIL
        // =================================

        tvRegisterOtpEmail.setText(
                "OTP sent to\n" + email
        );


        // =================================
        // SEND FIRST OTP
        // =================================

        generateAndSendOTP();


        // =================================
        // VERIFY OTP
        // =================================

        btnVerifyRegisterOtp.setOnClickListener(
                v -> {

                    String enteredOtp =
                            etRegisterOtp
                                    .getText()
                                    .toString()
                                    .trim();


                    if (enteredOtp.isEmpty()) {

                        etRegisterOtp.setError(
                                "Enter OTP"
                        );

                        return;
                    }


                    if (!enteredOtp.matches(
                            "\\d{6}"
                    )) {

                        etRegisterOtp.setError(
                                "Enter 6 digit OTP"
                        );

                        return;
                    }


                    // =================================
                    // CHECK OTP
                    // =================================

                    if (enteredOtp.equals(
                            generatedOtp
                    )) {

                        registerUser();

                    } else {

                        Toast.makeText(
                                RegisterOTPActivity.this,
                                "Incorrect OTP",
                                Toast.LENGTH_SHORT
                        ).show();

                        etRegisterOtp.setText("");
                    }

                }
        );


        // =================================
        // RESEND
        // =================================

        btnResendRegisterOtp.setOnClickListener(
                v -> {

                    etRegisterOtp.setText("");

                    generateAndSendOTP();

                }
        );
    }


// =========================================
// GENERATE + SEND OTP
// =========================================

    private void generateAndSendOTP() {

        Random random =
                new Random();

        int otp =
                100000 +
                        random.nextInt(900000);

        generatedOtp =
                String.valueOf(otp);


        btnResendRegisterOtp.setEnabled(
                false
        );


        // =================================
        // SEND EMAIL
        // =================================

        EmailSender.sendOtp(
                email,
                generatedOtp,
                new EmailSender.EmailCallback() {

                    @Override
                    public void onSuccess() {

                        runOnUiThread(() -> {

                            btnResendRegisterOtp
                                    .setEnabled(true);

                            Toast.makeText(
                                    RegisterOTPActivity.this,
                                    "OTP sent to your email",
                                    Toast.LENGTH_SHORT
                            ).show();

                        });
                    }


                    @Override
                    public void onFailure(
                            String error
                    ) {

                        runOnUiThread(() -> {

                            btnResendRegisterOtp
                                    .setEnabled(true);

                            Toast.makeText(
                                    RegisterOTPActivity.this,
                                    "Failed to send OTP",
                                    Toast.LENGTH_LONG
                            ).show();

                        });
                    }
                }
        );
    }


// =========================================
// REGISTER USER
// =========================================

    private void registerUser() {

        boolean result =
                dbHelper.registerUser(
                        name,
                        email,
                        password,
                        role
                );


        if (result) {

            Toast.makeText(
                    this,
                    "Account created successfully",
                    Toast.LENGTH_LONG
            ).show();


            Intent intent =
                    new Intent(
                            RegisterOTPActivity.this,
                            LoginActivity.class
                    );


            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );


            startActivity(intent);

            finish();

        } else {

            Toast.makeText(
                    this,
                    "Registration failed",
                    Toast.LENGTH_LONG
            ).show();
        }
    }


}