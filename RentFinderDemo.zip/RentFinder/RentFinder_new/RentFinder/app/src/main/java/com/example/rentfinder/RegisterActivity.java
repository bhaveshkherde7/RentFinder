package com.example.rentfinder;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

// =========================================
// VIEWS
// =========================================

    private EditText etName;
    private EditText etEmail;
    private EditText etPassword;

    private Spinner spinnerRole;

    private Button btnRegister;
    private Button btnGoLogin;

    private ImageButton btnShowPassword;


// =========================================
// DATABASE
// =========================================

    private DBHelper dbHelper;


// =========================================
// PASSWORD VISIBILITY
// =========================================

    private boolean passwordVisible = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_register
        );


        // =========================================
        // FIND VIEWS
        // =========================================

        etName =
                findViewById(
                        R.id.etName
                );

        etEmail =
                findViewById(
                        R.id.etEmail
                );

        etPassword =
                findViewById(
                        R.id.etPassword
                );

        spinnerRole =
                findViewById(
                        R.id.spinnerRole
                );

        btnRegister =
                findViewById(
                        R.id.btnRegister
                );

        btnGoLogin =
                findViewById(
                        R.id.btnGoLogin
                );

        btnShowPassword =
                findViewById(
                        R.id.btnShowPassword
                );


        // =========================================
        // DATABASE
        // =========================================

        dbHelper =
                new DBHelper(this);


        // =========================================
        // ROLE SPINNER
        // =========================================

        String[] roles = {
                "Student",
                "Owner"
        };


        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        roles
                );


        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );


        spinnerRole.setAdapter(
                adapter
        );


        // =========================================
        // SHOW / HIDE PASSWORD
        // =========================================

        btnShowPassword.setOnClickListener(
                v -> togglePassword()
        );


        // =========================================
        // REGISTER BUTTON
        // =========================================

        btnRegister.setOnClickListener(
                v -> registerUser()
        );


        // =========================================
        // GO TO LOGIN
        // =========================================

        btnGoLogin.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            RegisterActivity.this,
                            LoginActivity.class
                    );

            startActivity(intent);

            finish();

        });
    }


// =========================================
// TOGGLE PASSWORD
// =========================================

    private void togglePassword() {

        if (passwordVisible) {

            // ---------------------------------
            // HIDE PASSWORD
            // ---------------------------------

            etPassword.setInputType(
                    InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD
            );


            btnShowPassword.setImageResource(
                    R.drawable.ic_visibility_off
            );


            btnShowPassword.setContentDescription(
                    "Show password"
            );


            passwordVisible = false;


        } else {

            // ---------------------------------
            // SHOW PASSWORD
            // ---------------------------------

            etPassword.setInputType(
                    InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            );


            btnShowPassword.setImageResource(
                    R.drawable.ic_visibility
            );


            btnShowPassword.setContentDescription(
                    "Hide password"
            );


            passwordVisible = true;
        }


        // Keep cursor at end

        etPassword.setSelection(
                etPassword.length()
        );
    }


// =========================================
// REGISTER USER
// =========================================

    private void registerUser() {

        // =================================
        // GET VALUES
        // =================================

        String name =
                etName.getText()
                        .toString()
                        .trim();


        String email =
                etEmail.getText()
                        .toString()
                        .trim();


        String password =
                etPassword.getText()
                        .toString()
                        .trim();


        // =================================
        // GET ROLE SAFELY
        // =================================

        String role = "Student";


        if (spinnerRole.getSelectedItem() != null) {

            role =
                    spinnerRole
                            .getSelectedItem()
                            .toString();
        }


        // =================================
        // VALIDATE NAME
        // =================================

        if (name.isEmpty()) {

            etName.setError(
                    "Enter your full name"
            );

            etName.requestFocus();

            return;
        }


        // =================================
        // VALIDATE EMAIL
        // =================================

        if (email.isEmpty()) {

            etEmail.setError(
                    "Enter your email"
            );

            etEmail.requestFocus();

            return;
        }


        if (!android.util.Patterns.EMAIL_ADDRESS
                .matcher(email)
                .matches()) {

            etEmail.setError(
                    "Enter a valid email address"
            );

            etEmail.requestFocus();

            return;
        }


        // =================================
        // VALIDATE PASSWORD
        // =================================

        if (password.isEmpty()) {

            etPassword.setError(
                    "Enter password"
            );

            etPassword.requestFocus();

            return;
        }


        if (password.length() < 6) {

            etPassword.setError(
                    "Password must be at least 6 characters"
            );

            etPassword.requestFocus();

            return;
        }


        // =================================
        // CHECK EMAIL IN DATABASE
        // =================================

        if (dbHelper.isEmailRegistered(email)) {

            Toast.makeText(
                    RegisterActivity.this,
                    "Email already registered",
                    Toast.LENGTH_LONG
            ).show();

            etEmail.requestFocus();

            return;
        }


        // =================================
        // DISABLE BUTTON
        // Prevent double click
        // =================================

        btnRegister.setEnabled(false);


        // =================================
        // OPEN OTP ACTIVITY
        // =================================

        Intent intent =
                new Intent(
                        RegisterActivity.this,
                        RegisterOTPActivity.class
                );


        // =================================
        // SEND REGISTRATION DATA
        // =================================

        intent.putExtra(
                "name",
                name
        );

        intent.putExtra(
                "email",
                email
        );

        intent.putExtra(
                "password",
                password
        );

        intent.putExtra(
                "role",
                role
        );


        startActivity(intent);


        // Don't finish this activity.
        // OTP activity will handle registration.
    }


    @Override
    protected void onResume() {

        super.onResume();

        // Re-enable button when returning

        if (btnRegister != null) {

            btnRegister.setEnabled(true);
        }
    }


    @Override
    protected void onDestroy() {

        if (dbHelper != null) {

            dbHelper.close();
        }

        super.onDestroy();
    }


}