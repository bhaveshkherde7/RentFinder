package com.example.rentfinder;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailSender {

// =====================================================
// GMAIL ACCOUNT USED TO SEND OTP
// =====================================================

    private static final String SENDER_EMAIL =
            "YOUR_GMAIL@gmail.com";


// =====================================================
// GOOGLE APP PASSWORD
//
// IMPORTANT:
// Do NOT use your normal Gmail password.
// Use the 16-character Google App Password.
// =====================================================

    private static final String SENDER_PASSWORD =
            "YOUR_16_DIGIT_APP_PASSWORD";


// =====================================================
// SEND OTP
// =====================================================

    public static void sendOtp(
            String receiverEmail,
            String otp,
            EmailCallback callback
    ) {

        // Run email operation in background thread.
        new Thread(() -> {

            try {

                // =================================================
                // SMTP CONFIGURATION
                // =================================================

                Properties properties =
                        new Properties();

                properties.put(
                        "mail.smtp.auth",
                        "true"
                );

                properties.put(
                        "mail.smtp.starttls.enable",
                        "true"
                );

                properties.put(
                        "mail.smtp.host",
                        "smtp.gmail.com"
                );

                properties.put(
                        "mail.smtp.port",
                        "587"
                );

                properties.put(
                        "mail.smtp.connectiontimeout",
                        "10000"
                );

                properties.put(
                        "mail.smtp.timeout",
                        "10000"
                );

                properties.put(
                        "mail.smtp.writetimeout",
                        "10000"
                );


                // =================================================
                // CREATE MAIL SESSION
                // =================================================

                Session session =
                        Session.getInstance(
                                properties,
                                new Authenticator() {

                                    @Override
                                    protected PasswordAuthentication
                                    getPasswordAuthentication() {

                                        return new PasswordAuthentication(
                                                SENDER_EMAIL,
                                                SENDER_PASSWORD
                                        );
                                    }
                                }
                        );


                // =================================================
                // CREATE EMAIL MESSAGE
                // =================================================

                Message message =
                        new MimeMessage(session);


                // =================================================
                // FROM
                // =================================================

                message.setFrom(
                        new InternetAddress(
                                SENDER_EMAIL,
                                "UniStay"
                        )
                );


                // =================================================
                // TO
                // =================================================

                message.setRecipients(
                        Message.RecipientType.TO,
                        InternetAddress.parse(
                                receiverEmail
                        )
                );


                // =================================================
                // SUBJECT
                // =================================================

                message.setSubject(
                        "UniStay - Registration OTP"
                );


                // =================================================
                // EMAIL BODY
                // =================================================

                String emailBody =
                        "Hello,\n\n"
                                + "Welcome to UniStay!\n\n"
                                + "Your verification OTP is:\n\n"
                                + otp
                                + "\n\n"
                                + "Please enter this OTP in the UniStay "
                                + "app to complete your registration."
                                + "\n\n"
                                + "If you did not create a UniStay account, "
                                + "please ignore this email."
                                + "\n\n"
                                + "Regards,\n"
                                + "UniStay Team";


                message.setText(
                        emailBody
                );


                // =================================================
                // SEND EMAIL
                // =================================================

                Transport.send(
                        message
                );


                // =================================================
                // SUCCESS
                // =================================================

                if (callback != null) {

                    callback.onSuccess();

                }


            } catch (Exception e) {

                e.printStackTrace();


                // =================================================
                // FAILURE
                // =================================================

                if (callback != null) {

                    callback.onFailure(
                            e.getClass().getSimpleName()
                                    + ": "
                                    + e.getMessage()
                    );

                }

            }

        }).start();
    }


// =====================================================
// CALLBACK
// =====================================================

    public interface EmailCallback {

        void onSuccess();

        void onFailure(String error);
    }


}