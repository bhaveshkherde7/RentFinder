package com.example.rentfinder;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class RegisterOTPActivity extends AppCompatActivity {

    private EditText etRegisterOtp;

    private Button btnVerifyRegisterOtp;
    private Button btnResendRegisterOtp;

    private TextView tvRegisterOtpEmail;

    private String name;
    private String email;
    private String password;
    private String role;

    private String generatedOtp;

    private DBHelper dbHelper;

    private Toast currentToast;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register_otp);


        // =========================================
        // FIND VIEWS
        // =========================================

        etRegisterOtp =
                findViewById(R.id.etRegisterOtp);

        btnVerifyRegisterOtp =
                findViewById(R.id.btnVerifyRegisterOtp);

        btnResendRegisterOtp =
                findViewById(R.id.btnResendRegisterOtp);

        tvRegisterOtpEmail =
                findViewById(R.id.tvRegisterOtpEmail);


        // =========================================
        // DATABASE
        // =========================================

        dbHelper = new DBHelper(this);


        // =========================================
        // GET REGISTER DATA
        // =========================================

        name =
                getIntent().getStringExtra("name");

        email =
                getIntent().getStringExtra("email");

        password =
                getIntent().getStringExtra("password");

        role =
                getIntent().getStringExtra("role");

        generatedOtp =
                getIntent().getStringExtra("otp");


        // =========================================
        // VALIDATE NAME
        // =========================================

        if (name == null || name.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    "Name is missing",
                    Toast.LENGTH_LONG
            ).show();

            finish();

            return;
        }


        // =========================================
        // VALIDATE EMAIL
        // =========================================

        if (email == null || email.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    "Email is missing",
                    Toast.LENGTH_LONG
            ).show();

            finish();

            return;
        }


        // =========================================
        // VALIDATE PASSWORD
        // =========================================

        if (password == null || password.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    "Password is missing",
                    Toast.LENGTH_LONG
            ).show();

            finish();

            return;
        }


        // =========================================
        // VALIDATE ROLE
        // =========================================

        if (role == null || role.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    "Role is missing",
                    Toast.LENGTH_LONG
            ).show();

            finish();

            return;
        }


        // =========================================
        // DISPLAY EMAIL
        // =========================================

        tvRegisterOtpEmail.setText(
                "OTP sent to\n" + email
        );


        // =========================================
        // GENERATE OTP IF REQUIRED
        // =========================================

        if (generatedOtp == null ||
                generatedOtp.trim().isEmpty()) {

            generateOTP();

        } else {

            showOtpToast(generatedOtp);
        }


        // =========================================
        // VERIFY OTP
        // =========================================

        btnVerifyRegisterOtp.setOnClickListener(v -> {

            String enteredOtp =
                    etRegisterOtp
                            .getText()
                            .toString()
                            .trim();


            // =====================================
            // EMPTY OTP
            // =====================================

            if (enteredOtp.isEmpty()) {

                etRegisterOtp.setError(
                        "Enter OTP"
                );

                etRegisterOtp.requestFocus();

                return;
            }


            // =====================================
            // OTP LENGTH
            // =====================================

            if (!enteredOtp.matches("\\d{6}")) {

                etRegisterOtp.setError(
                        "Enter 6 digit OTP"
                );

                etRegisterOtp.requestFocus();

                return;
            }


            // =====================================
            // VERIFY
            // =====================================

            if (enteredOtp.equals(generatedOtp)) {

                registerUser();

            } else {

                Toast.makeText(
                        RegisterOTPActivity.this,
                        "Incorrect OTP",
                        Toast.LENGTH_SHORT
                ).show();

                etRegisterOtp.setText("");
            }
        });


        // =========================================
        // RESEND OTP
        // =========================================

        btnResendRegisterOtp.setOnClickListener(v -> {

            etRegisterOtp.setText("");

            generateOTP();
        });
    }


    // =====================================================
    // GENERATE OTP
    // =====================================================

    private void generateOTP() {

        Random random =
                new Random();

        int otp =
                100000 +
                        random.nextInt(900000);

        generatedOtp =
                String.valueOf(otp);


        // =========================================
        // SHOW OTP
        // =========================================

        showOtpToast(generatedOtp);
    }


    // =====================================================
    // SHOW OTP FOR APPROXIMATELY 4 SECONDS
    // =====================================================

    private void showOtpToast(String otp) {

        // Cancel previous Toast

        if (currentToast != null) {

            currentToast.cancel();
        }


        // Create Toast

        currentToast =
                Toast.makeText(
                        RegisterOTPActivity.this,
                        "Your OTP is: " + otp,
                        Toast.LENGTH_LONG
                );


        // Show Toast

        currentToast.show();


        // Cancel after 4 seconds

        new Handler(Looper.getMainLooper())
                .postDelayed(() -> {

                    if (currentToast != null) {

                        currentToast.cancel();

                        currentToast = null;
                    }

                }, 4000);
    }


    // =====================================================
    // REGISTER USER
    // =====================================================

    private void registerUser() {

        // =========================================
        // CHECK EMAIL
        // =========================================

        if (dbHelper.isEmailRegistered(email)) {

            Toast.makeText(
                    this,
                    "Email already registered",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }


        // =========================================
        // SAVE USER
        // =========================================

        boolean result =
                dbHelper.registerUser(
                        name,
                        email,
                        password,
                        role
                );


        // =========================================
        // SUCCESS
        // =========================================

        if (result) {

            Toast.makeText(
                    this,
                    "Account created successfully",
                    Toast.LENGTH_LONG
            ).show();


            Intent intent =
                    new Intent(
                            RegisterOTPActivity.this,
                            LoginActivity.class
                    );


            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );


            startActivity(intent);

            finish();

        } else {

            Toast.makeText(
                    this,
                    "Registration failed",
                    Toast.LENGTH_LONG
            ).show();
        }
    }


    // =====================================================
    // DESTROY
    // =====================================================

    @Override
    protected void onDestroy() {

        if (currentToast != null) {

            currentToast.cancel();

            currentToast = null;
        }


        if (dbHelper != null) {

            dbHelper.close();
        }


        super.onDestroy();
    }
}
